const express = require('express');
const router = express.Router();
const auth = require('../middlewares/auth');
const Poster = require('../models/Poster');
const Evaluation = require('../models/Evaluation');

router.post('/', auth, async (req, res) => {
  try {
    const p = new Poster({ ...req.body, author: req.user.id });
    await p.save();
    res.status(201).json(p);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const p = await Poster.findById(req.params.id).populate('author','name email');
    res.json(p);
  } catch (err) { res.status(404).json({ error: 'Not found' }); }
});

router.get('/', async (req, res) => {
  const list = await Poster.find().limit(50).sort({ createdAt: -1 });
  res.json(list);
});

router.post('/:id/evaluate', auth, async (req, res) => {
  try {
    const ev = new Evaluation({ poster: req.params.id, juror: req.user.id, scores: req.body.scores, comments: req.body.comments });
    await ev.save();
    res.status(201).json(ev);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

router.get('/:id/evaluations', async (req, res) => {
  const evs = await Evaluation.find({ poster: req.params.id }).populate('juror','name email');
  res.json(evs);
});

module.exports = router;
