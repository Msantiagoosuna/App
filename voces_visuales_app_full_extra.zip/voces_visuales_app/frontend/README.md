# Frontend - Voces Visuales (minimal)

Quick start instructions in the repository root.
