require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const User = require('./models/User');
const Poster = require('./models/Poster');

(async () => {
  await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/voces');
  console.log('DB connected');
  await User.deleteMany({});
  await Poster.deleteMany({});

  const admin = new User({
    name: 'Admin',
    email: 'admin@voces.com',
    password: await bcrypt.hash('admin123', 10),
    role: 'admin'
  });
  const juror = new User({
    name: 'Jurado',
    email: 'jurado@voces.com',
    password: await bcrypt.hash('jurado123', 10),
    role: 'juror'
  });
  const participant = new User({
    name: 'Participante',
    email: 'user@voces.com',
    password: await bcrypt.hash('user123', 10),
    role: 'participant'
  });

  await admin.save();
  await juror.save();
  await participant.save();

  await Poster.create({
    title: 'Prevención y detección temprana del cáncer',
    introduction: 'Campaña educativa dirigida a adolescentes',
    methodology: 'Revisión de literatura PubMed y Scielo',
    results: 'Incremento de conocimiento del 40%',
    references: 'DOI:10.1016/j.ca.2024.01.003',
    author: participant._id
  });

  console.log('Seed completado ✅');
  process.exit();
})().catch(err=>{ console.error(err); process.exit(1); });
