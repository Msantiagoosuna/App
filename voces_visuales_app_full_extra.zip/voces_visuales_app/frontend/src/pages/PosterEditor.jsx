import React, { useState } from "react";
import API from "../utils/api";\nimport { contrastRatio } from "../utils/contrast";\nimport { analyzeText } from "../utils/textAnalysis";

export default function PosterEditor() {
  const [form, setForm] = useState({
    title: "",
    introduction: "",
    methodology: "",
    results: "",
    references: ""
  });
  const [message, setMessage] = useState("");\n  const [analysis, setAnalysis] = useState([]);\n  const [contrastResult, setContrastResult] = useState(null);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post('/posters', form);
      setMessage('✅ Cartel guardado correctamente');
      console.log(res.data);
    } catch (err) {
      setMessage('❌ Error: ' + (err.response?.data?.error || err.message));
    }
  };

  return (
    <div style={{padding:20}}>
      <h2 style={{color:'#0b4da2'}}>Editor de Cartel — Voces Visuales</h2>
      <form onSubmit={handleSubmit} style={{display:'grid',gap:12,maxWidth:800}}>
        {['title','introduction','methodology','results','references'].map(f=> (
          <div key={f}>
            <label style={{fontWeight:600, textTransform:'capitalize'}}>{f}</label>
            <textarea name={f} value={form[f]} onChange={handleChange} rows={4} style={{width:'100%',padding:8,borderRadius:6,border:'1px solid #ddd'}} required={f==='title'} />
          </div>
        ))}
        <div>
          <button type="submit" style={{background:'#0b4da2',color:'#fff',padding:'8px 12px',borderRadius:8}}>Guardar cartel</button>
        </div>
      </form>
      {message && <p style={{marginTop:12}}>{message}</p>}\n      {contrastResult && <div style={{marginTop:12}}><strong>Contraste:</strong> {contrastResult.ratio} (pass AA: {String(contrastResult.passAA)})</div>}\n      {analysis && analysis.length>0 && <div style={{marginTop:12}}><strong>Analysis:</strong><ul>{analysis.map((a,i)=>(<li key={i}>{a.message}</li>))}</ul></div>}
    </div>
  )
}
