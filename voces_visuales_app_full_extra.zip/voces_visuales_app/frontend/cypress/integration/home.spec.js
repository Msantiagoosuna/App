describe('Voces Visuales app', ()=>{
  it('loads home', ()=>{
    cy.visit('/');
    cy.contains('Voces Visuales');
  });
});
