# Voces Visuales App - Scaffold

See backend/ and frontend/ folders.

## Adicionales incluidas
- `frontend/src/pages/PosterEditor.jsx` — editor visual mínimo y conectado al backend.
- `frontend/src/utils/api.js` — helper axios para llamadas API.
- `backend/src/seed.js` — script para poblar DB con usuarios y un cartel de ejemplo.
- `.github/workflows/deploy.yml` — pipeline CI básico (personalizar deploy).

### Ejecutar seed locally
1. Configure `.env` en `backend` (MONGO_URI).
2. `cd backend && node src/seed.js`

### Ejecutar la app con Docker Compose (desarrollo)
`docker-compose up --build`

## Avanzado añadido (despliegue, tests y análisis de contenido)

### Deploy
- Añade los secretos en tu repo: `RENDER_API_KEY`, `RENDER_SERVICE_ID_BACKEND`, `RENDER_SERVICE_ID_FRONTEND` y `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`.
- Los workflows para deploy se encuentran en `.github/workflows/`.

### Tests
- Backend (Jest + supertest):
  - `cd backend && npm ci && npm test`
- E2E (Cypress):
  - `cd frontend && npx cypress open` y ejecuta `home.spec.js`.

### Editor - mejoras
- `frontend/src/utils/contrast.js` -> calculadora de contraste WCAG.
- `frontend/src/utils/textAnalysis.js` -> heurísticas ligeras para sugerencias sobre redacción.
- PosterEditor ahora integra análisis y muestra resultados.
