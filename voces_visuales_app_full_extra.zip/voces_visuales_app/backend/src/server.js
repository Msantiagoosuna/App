require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const authRoutes = require('./routes/auth.routes');
const posterRoutes = require('./routes/poster.routes');

app.use('/api/auth', authRoutes);
app.use('/api/posters', posterRoutes);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Internal server error' });
});

const PORT = process.env.PORT || 4000;
mongoose.connect(process.env.MONGO_URI, { })
  .then(()=> app.listen(PORT, ()=> console.log(`Server on ${PORT}`)))
  .catch(err => { console.error(err); process.exit(1); });
