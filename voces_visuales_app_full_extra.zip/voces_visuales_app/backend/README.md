# Backend - Voces Visuales App (minimal scaffold)

Quick start instructions in the repository root.
