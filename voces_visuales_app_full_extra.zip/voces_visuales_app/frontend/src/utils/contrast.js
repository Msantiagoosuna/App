/**
 * Simple WCAG contrast ratio calculator
 * Returns ratio and pass boolean for level AA (4.5:1 for normal text)
 * Usage: checkContrast('#ffffff', '#0b4da2')
 */
function hexToRgb(hex){ 
  const h = hex.replace('#','');
  const bigint = parseInt(h,16);
  if(h.length===6){
    return { r: (bigint>>16)&255, g:(bigint>>8)&255, b: bigint&255 };
  }
  return { r:0,g:0,b:0 };
}
function luminance(color){
  const rsrgb = color.r/255; const gsrgb = color.g/255; const bsrgb = color.b/255;
  const r = rsrgb<=0.03928 ? rsrgb/12.92 : Math.pow((rsrgb+0.055)/1.055,2.4);
  const g = gsrgb<=0.03928 ? gsrgb/12.92 : Math.pow((gsrgb+0.055)/1.055,2.4);
  const b = bsrgb<=0.03928 ? bsrgb/12.92 : Math.pow((bsrgb+0.055)/1.055,2.4);
  return 0.2126*r + 0.7152*g + 0.0722*b;
}
export function contrastRatio(hex1, hex2){
  try{
    const c1 = hexToRgb(hex1); const c2 = hexToRgb(hex2);
    const L1 = luminance(c1); const L2 = luminance(c2);
    const lighter = Math.max(L1,L2); const darker = Math.min(L1,L2);
    const ratio = (lighter+0.05)/(darker+0.05);
    return { ratio: Number(ratio.toFixed(2)), passAA: ratio>=4.5, passAALarge: ratio>=3 };
  }catch(e){ return { ratio:0, passAA:false, passAALarge:false }; }
}
