const request = require('supertest');

describe('Basic API', ()=>{
  it('GET /api/posters should return 200', async ()=>{
    const res = await request('http://localhost:4000').get('/api/posters');
    expect([200,404]).toContain(res.statusCode); // 200 if server running, 404 if route not ready
  }, 10000);
});
