import React from 'react'

export default function Home(){
  return (
    <div style={{fontFamily:'Inter, sans-serif', padding:24}}>
      <header style={{display:'flex',alignItems:'center',gap:12}}>
        <div style={{width:56,height:56,background:'#0b4da2',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center',color:'#fff',fontWeight:700}}>VV</div>
        <div>
          <h1>Voces Visuales — Prototipo</h1>
          <p style={{margin:0,color:'#555'}}>Plataforma para creación y evaluación de carteles</p>
        </div>
      </header>
      <main style={{marginTop:24,display:'grid',gridTemplateColumns:'1fr 320px',gap:24}}>
        <section style={{background:'#fff',padding:16,borderRadius:8,boxShadow:'0 1px 4px rgba(0,0,0,0.06)'}}>
          <h2>Crear cartel</h2>
          <p>Editor simplificado disponible en el repositorio.</p>
        </section>
        <aside style={{background:'#fff',padding:16,borderRadius:8}}>
          <h3>Puntuación ejemplo</h3>
          <div style={{fontSize:28,fontWeight:700}}>36 / 36</div>
        </aside>
      </main>
    </div>
  )
}
