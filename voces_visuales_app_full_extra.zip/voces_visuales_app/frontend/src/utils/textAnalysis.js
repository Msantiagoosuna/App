/**
 * Basic client-side text analysis to give suggestions (not a full spellcheck)
 * - Detects very long sentences (>28 words)
 * - Detects repeated consecutive words
 * - Flags common passive voice patterns (was, were + past participle heuristic)
 */
export function analyzeText(text){
  const sentences = text.split(/[\.\?!\n]+/).map(s=>s.trim()).filter(Boolean);
  const issues = [];
  sentences.forEach((s, idx)=>{
    const words = s.split(/\s+/).filter(Boolean);
    if(words.length>28) issues.push({ type:'long_sentence', message:`Sentence ${idx+1} is long (${words.length} words)` });
    for(let i=0;i<words.length-1;i++){
      if(words[i].toLowerCase()===words[i+1].toLowerCase()){
        issues.push({ type:'repeated_word', message:`Repeated word '${words[i]}' in sentence ${idx+1}` });
      }
    }
    // passive voice naive check
    const passiveRegex = /\b(was|were|is|are|been|be)\s+\w+ed\b/i;
    if(passiveRegex.test(s)) issues.push({ type:'passive_voice', message:`Possible passive voice in sentence ${idx+1}` });
  });
  // simple word frequency (flag unusual many repeats)
  const allWords = text.toLowerCase().split(/\W+/).filter(Boolean);
  const freq = {};
  allWords.forEach(w=> freq[w]=(freq[w]||0)+1);
  const repeats = Object.entries(freq).filter(([w,c])=> c>8 && w.length>3).slice(0,5);
  repeats.forEach(([w,c])=> issues.push({ type:'frequent_word', message:`The word '${w}' appears ${c} times` }));
  return issues;
}
