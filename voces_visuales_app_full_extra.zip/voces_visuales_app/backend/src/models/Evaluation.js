const mongoose = require('mongoose');
const EvaluationSchema = new mongoose.Schema({
  poster: { type: mongoose.Schema.Types.ObjectId, ref: 'Poster' },
  juror: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  scores: Object,
  comments: String,
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Evaluation', EvaluationSchema);
