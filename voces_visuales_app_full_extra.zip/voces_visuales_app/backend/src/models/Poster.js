const mongoose = require('mongoose');
const PosterSchema = new mongoose.Schema({
  title: String,
  introduction: String,
  methodology: String,
  results: String,
  references: String,
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  media: [String],
  createdAt: { type: Date, default: Date.now }
});
module.exports = mongoose.model('Poster', PosterSchema);
